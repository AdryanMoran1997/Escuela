def LinearSearch(lys, element):
    for i in range (len(lys)):
        if lys[i] == element:
            return i
            break