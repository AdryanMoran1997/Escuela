import time
import random

def serverMock(maxi = 90):
    """
    This function is used to mock a server.

    :return: A boolean representing if the server is up or down.
    """
    status = False
    duration = random.randint(1, 10)
    iteration = 0

    while not maxi or maxi > iteration:
        for i in range(duration):
            yield status
            iteration += 1
        duration = random.randint(1, 10)
        status = random.random() < 0.67

def main():
    """
    This function is used to run the server.
    """
    SU=0
    SD=0
    InF=0
    FiF=0
    Rec=0
    for status in serverMock():
        print("     Server is {}".format("up" if status else "down"))
        #time.sleep(.1)
        
        if status == True:
            SU=SU+1
        else:
            SD += 1
            if SU==0:
                InF += 1
    
    FS=(SD/(SD+SU))*100
    #print(SU,SD,(SD+SU))

    print("Tiempo medio hasta restablecer despues de una falla es: {:.2f}".format(InF))
    print("El servidor estuvo caido el {:.2f} % del tiempo".format(FS))
    print()

if __name__ == "__main__":
    main()