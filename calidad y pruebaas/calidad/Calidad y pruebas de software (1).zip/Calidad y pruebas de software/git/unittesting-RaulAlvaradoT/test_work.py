import unittest
import work

class TestWork(unittest.TestCase):
    def test_square(self):
        cases = [
            (5, 25),
            (7, 49),
            (21, 441),
            (-4, 16) #Se agregan negativos, sin problema
        ]

        for inp, expected in cases:
            with self.subTest(inp=inp, expected=expected):
                obtained = work.square(inp)
                self.assertEqual(obtained, expected, "square(%s) should be %s" % (inp, expected))

    def test_triple(self):
        cases = [
            (7, 21),
            (12, 36),
            (135, 405),
            (-6, -18) #Se agregan negativos, sin problema
        ]

        for inp , expected in cases:
            with self.subTest(inp=inp, expected=expected):
                obtained = work.triple(inp)
                self.assertEqual(obtained, expected, "triple(%s) should be %s" % (inp, expected))
    
    def test_minNum(self):
        cases = [
            ([1,3,6,11,5],1),
            ([1,5,20,31,0,17],0),
            ([15,16,25,24,2],2),
            ([-5,-6,-2,4,-4],-6) #Se agregan negativos, sin problema
        ]

        for inp , expected in cases:
            with self.subTest(inp=inp, expected=expected):
                obtained = work.minNum(inp)
                self.assertEqual(obtained, expected, "the minimun number(%s) should be %s" % (inp, expected))
    
    def test_sumArray(self):
        cases = [
            ([1,5,7],13),
            ([15,30,25],70),
            ([0,0,0],0),
            ([-5,5,-2],-2)
        ]

        for inp , expected in cases:
            with self.subTest(inp=inp, expected=expected):
                obtained = work.sumArray(inp)
                self.assertEqual(obtained, expected, "the sum(%s) should be %s" % (inp, expected))

    def test_bubbleSort(self):
        cases = [
            ([5, 3, 5, 1, 9, 2, 4, 7, 8, 6, 12], [1, 2, 3, 4, 5, 5, 6, 7, 8, 9, 12]),
            ([1, 2, 3, 4, 5], [1, 2, 3, 4, 5]),
            ([9, 8, 7, 6, 5, 4, 3, 2, 1], [1, 2, 3, 4, 5, 6, 7, 8, 9]), 
        ]

        for inp , expected in cases:
            with self.subTest(inp=inp, expected=expected):
                obtained = work.bubbleSort(inp)
                self.assertEqual(obtained, expected, "the numbers in disorder(%s) should be %s" % (inp, expected))

if __name__ == '__main__':
    unittest.main()