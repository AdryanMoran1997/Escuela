import time
numero = 35

#   Metodo recursivo

# 1. Obtener el tiempo inicial
inicio = time.time()
# 2. Ejecutar el codigo
def fiboRecursivo(n):
    time.sleep(0.00001)
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fiboRecursivo(n-1) + fiboRecursivo(n-2)
fibo = fiboRecursivo(numero)
# 3. Obtener el tiempo final
fin = time.time()
# 4. Calcular y devolver la diferencia de tiempo
print("Recursivo de: ",fibo," tarda en ejecutarse: ",fin-inicio,"seg","\n")


#   Metodo iterativo

# 1. Obtener el tiempo inicial
inicio2 = time.time()
# 2. Ejecutar el codigo
def fibonacci_iterativo(posicion):
    time.sleep(0.00001)
    actual = 0
    siguiente = 1
    for x in range(posicion + 1):
        temporal = actual
        actual = siguiente
        siguiente = siguiente + temporal
    return temporal
fibo2 = fibonacci_iterativo(numero)
# 3. Obtener el tiempo final
fin2 = time.time()
# 4. Calcular y devolver la diferencia de tiempo
print("Iterativo de: ",fibo2," tarda en ejecutarse: ",fin2-inicio2,"seg")