print("¿En que semestre estas?")
Res = input()
print(f"{Res}")
