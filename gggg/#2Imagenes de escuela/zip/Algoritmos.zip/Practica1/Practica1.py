lista_numeros = input().split()
valor1=lista_numeros[0]
valor2=lista_numeros[1]

suma = int(valor1) + int(valor2) 

print(suma)