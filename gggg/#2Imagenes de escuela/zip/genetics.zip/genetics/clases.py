from itertools import permutations
import numpy as np

from settings import *
from needleman_wunsch import *

class Cromosoma:
    def __init__(self, hijo=False):
        material = hijo if hijo else np.random.choice(ELEMENTOS, LONGITUD)
        self.aminoacidos = material
    
    def get(self):
        return self.aminoacidos
    
    def set(self, aminoacidos):
        self.aminoacidos = aminoacidos

    def juntar(self):
        return ''.join([a if a != '-' else '' for a in self.aminoacidos])
    
    def __str__(self):
        return ''.join(self.aminoacidos)

class Individuo:
    def __init__(self, hijo = False):
        self.cromosomas = []
        for _ in range(SECUENCIAS):
            material = Cromosoma(hijo) if hijo else Cromosoma()
            self.cromosomas.append(material)
    
    # Se alinean en parejas consecutivas y automaticamente se evalua
    def alinear(self):
        for i in range(SECUENCIAS-1):
            a1, a2 = nw(self.cromosomas[i].juntar(), self.cromosomas[i+1].juntar())
            self.cromosomas[i], self.cromosomas[i+1] = Cromosoma(a1), Cromosoma(a2)
        self.evaluar()
    
    def partir(self, n):
        cromosomas = []
        for c in self.cromosomas:
            c = c.juntar()
            cromosomas.append([c[i:i+n] for i in range(0, len(c), n)])
        return cromosomas
    
    def get(self):
        return [c for c in self.cromosomas]
    
    def set(self, cromosomas):
        self.cromosomas = cromosomas
    
    # Algoritmo solo evalua alineaciones perfectas
    def evaluar(self):
        matches = 0
        for i in range(LONGITUD):
            aminoacidos = []
            for j in range(SECUENCIAS):
                aminoacidos.append(str(self.cromosomas[j])[i])
            if len(set(aminoacidos)) <= 1:
                matches +=1

        self.fitness = matches
        return matches
    
    def __str__(self):
        return '\n'.join([str(c) for c in self.cromosomas])

class Poblacion:
    def __init__(self):
        # Se revisa que las partes deseadas sean viables
        if PARTES < 1 or PARTES > LONGITUD:
            raise ValueError('No puedes alterar materia')
        
        if isinstance(SEMILLA, int):
            np.random.seed(SEMILLA)
        else:
            np.random.seed()
        
        p = POBLACION
        self.parejas = p if p%2 == 0 else p - p%2

        self.individuos = []
        for _ in range(p):
            individuo = Individuo()
            individuo.alinear()
            self.individuos.append(individuo)
    
    def rellenar(self):
        for _ in range(POBLACION-len(self.individuos)):
            ind = Individuo()
            ind.alinear()
            self.individuos.append(ind)

    def descartar(self):
        arr = self.individuos
        n = len(arr)

        for i in range(n):
            for j in range(0, n-i-1):
                if arr[j].fitness < arr[j+1].fitness:
                    arr[j], arr[j+1] = arr[j+1], arr[j]
        self.individuos = arr[:TOP]
    
    # Toma dos Matrices y las cruza
    # se alterna la toma de elementos simple y automaticamente se alinea
    def procrear(self, x, y):
        n = round(LONGITUD / PARTES)
        padre = x.partir(n)
        madre = y.partir(n)

        hijo = [""]*SECUENCIAS
        for i in range(SECUENCIAS):
            for j in range(len(padre)):
                material = padre[i][j] if j%2 == 0 else madre[i][j]
                hijo[i]+= material
        print(hijo)
        hijo = Individuo(hijo)
        hijo.alinear()
        return hijo
    
    # Algoritmo de procreacion y descarte, pasando a la siguiente generacion
    # solo se procrea un hijo por pareja y solo un
    # Individuo con otro, sin repeticion, solo pares
    def siguiente(self):
        beta = []
        for i in range(self.parejas):
            padre, madre = self.individuos[i], self.individuos[i+1]
            beta.append(self.procrear(padre, madre))
    
    def imprimir(self):
        for i in range(len(self.individuos)):
            obj = self.individuos[i]
            print(f'Individuo {i}:\nCalificacion {obj.fitness}\n{str(obj)}\n')
