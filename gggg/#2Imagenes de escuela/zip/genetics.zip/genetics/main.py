from settings import *
from clases import *

if __name__ == '__main__':
    pob = Poblacion()
    for i in range(GENERACIONES):
        print(f'-------------- GENERACION {i} -------------\n')
        pob.imprimir()
        pob.siguiente()
        pob.descartar()
        if i<GENERACIONES-1:
            pob.rellenar()
    
    print('----FINAL----\n')
    pob.imprimir()
