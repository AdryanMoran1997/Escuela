#Configuracion del programa
#El algoritmo utilizado es Needleman-Wunsch (https://en.wikipedia.org/wiki/Needleman%E2%80%93Wunsch_algorithm)
#Sacado de GitHub https://gist.github.com/slowkow/06c6dba9180d013dfd82bec217d22eb5

#Cantidad de Matrices (Individuos) que estaran en una generacion
POBLACION = 5
#Se define la poblacion inicial, si la poblacion es menor al numero definido arriba, se crean aleatorias
#Si la cantidad de individuos en una generacion es menor, se agregan aleatorios (aun no se implementa)
INDIVIDUOS = []
# Numero de veces que se procrean
GENERACIONES = 3
# Cantidad de individuos que deben de quedar despues de la evaluacion (los mejores)
TOP = 3
# Numero de partes en las que se dividiran los padres para formar al hijo (menor a la longitud)
PARTES = 4

# Cantidad de Secuencias en una Matriz (Individuo)
SECUENCIAS = 2
# Definicion de los posibles valores dentro de la secuencia (Aminoacidos)
ELEMENTOS = ['A', 'C', 'G', 'T']
# Longitud de las Secuencias (Cromosomas) que tendra un Individuo
LONGITUD = 15

# Determinara la aleatoridad o falta de ella (poner un string 'random' para ser aleatorio)
SEMILLA = 1452
