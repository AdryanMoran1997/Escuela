﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Agregamos las columnas con su respectivo nombre al DataGridView
        DataGridView_agregarColumnas()
    End Sub

    Private Sub DataGridView_agregarColumnas()
        Dim cantidadColumnas As Integer = 6
        Dim nombres_columnas = {"Nombre(s)", "Primer Apellido", "Segundo Apellido",
            "Matrícula", "Escolaridad", "Fecha de Nacimiento"}
        DataGridView1.ColumnCount = cantidadColumnas

        For i = 0 To (cantidadColumnas - 1)
            DataGridView1.Columns(i).Name = nombres_columnas(i)
        Next i
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Cargamos el Form1 al clickear el boton Agregar en el Form2
        Form1.Show()
    End Sub
End Class