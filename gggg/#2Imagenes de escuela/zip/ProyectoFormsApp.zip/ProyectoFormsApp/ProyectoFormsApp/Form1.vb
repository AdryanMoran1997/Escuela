﻿Public Class Form1
    Public alumnos As ArrayList = New ArrayList

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim nombre = Me.TextBox1.Text
        Dim primerApellido = Me.TextBox2.Text
        Dim segundoApellido = Me.TextBox3.Text
        Dim matricula = CInt(Me.TextBox4.Text)
        Dim gradoEscolaridad = Me.ComboBox1.SelectedItem
        Dim fechaNacimiento = Me.DateTimePicker1.Value

        Dim alumno As Alumno = New Alumno(nombre, primerApellido,
                                           segundoApellido, matricula,
                                           gradoEscolaridad, fechaNacimiento)
        alumnos.Add(alumno)
        agregarAlumno()
        Me.Close()
    End Sub

    Private Sub agregarAlumno()
        Dim alumno As Alumno = alumnos(0)
        ' Agregamos el alumno registrado al DataGridView
        Form2.DataGridView1.Rows.Add(alumno.nombre, alumno.primerApellido,
                                     alumno.segundoApellido, alumno.matricula,
                                     alumno.gradoEscolaridad, alumno.fechaNacimiento)
        alumnos.Clear()
    End Sub
End Class
