﻿Public Class Alumno
    Public nombre As String
    Public primerApellido As String
    Public segundoApellido As String
    Public matricula As Integer
    Public gradoEscolaridad As String
    Public fechaNacimiento As Date

    Public Sub New(nombre As String, primerApellido As String,
                   segundoApellido As String, matricula As Integer,
                   gradoEscolaridad As String, fechaNacimiento As Date)
        Me.nombre = nombre
        Me.primerApellido = primerApellido
        Me.segundoApellido = segundoApellido
        Me.matricula = matricula
        Me.gradoEscolaridad = gradoEscolaridad
        Me.fechaNacimiento = fechaNacimiento
    End Sub
End Class
