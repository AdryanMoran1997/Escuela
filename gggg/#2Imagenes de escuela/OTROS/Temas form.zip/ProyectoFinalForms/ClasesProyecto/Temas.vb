﻿Imports System.Data.SqlClient
Public Class Temas
#Region "Definicion de propiedades"
    Private MstrTema As String
    Private MstrObjetivo As String

#End Region
#Region "Hacer publico el acceso a las propiedades"
    Public Property Tema() As String
        Get
            Return MstrTema
        End Get
        Set(ByVal value As String)
            MstrTema = value
        End Set
    End Property
    Public Property Objetivo() As String
        Get
            Return MstrObjetivo
        End Get
        Set(ByVal value As String)
            MstrObjetivo = value
        End Set
    End Property

#End Region
#Region "Definicion de metodos"


    Public Function TemaConsulta() As Boolean
        Dim cnx As New SqlConnection("Server=LAPTOP-5G895NKL; database=ProyectoFinal; Integrated Security=True;")
        Dim cmd As New SqlCommand("dbo.TemaConsulta", cnx)
        cmd.CommandType = CommandType.StoredProcedure
        Dim ObjetivoTema1 As String
        Dim pasar As Boolean
        cmd.Parameters.Add(New SqlParameter("@Tema", MstrTema))
        cnx.Open()
        Dim leer As SqlDataReader
        leer = cmd.ExecuteReader
        If leer.Read() Then
            ObjetivoTema1 = leer(1).ToString

            Objetivo = ObjetivoTema1

            cnx.Close()

        End If
        If pasar Then
            Return False
        Else
            Return True
        End If
    End Function
#End Region
End Class
