﻿Imports System.Data.SqlClient

Public Class Usuario
    Private _Nombre As String
    Private _Contrasena As String
    Private _IsAdmin As Integer

    Public Property Nombre As String
        Get
            Return _Nombre
        End Get
        Set
            _Nombre = Value
        End Set


    End Property

    Public Property Contrasena As String
        Get
            Return _Contrasena
        End Get
        Set
            _Contrasena = Value
        End Set
    End Property

    Public Property IsAdmin As Integer
        Get
            Return _IsAdmin
        End Get
        Set
            _IsAdmin = Value
        End Set
    End Property


    Public Function IniciarSesion() As Integer
        Dim existe As New Integer
        Dim cnx As New SqlConnection("Server=LAPTOP-5G895NKL; database=ProyectoFinal; Integrated Security=True;")
        Dim cmd As New SqlCommand("dbo.UsuInicio", cnx)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add(New SqlParameter("@Nombre", _Nombre))
        cmd.Parameters.Add(New SqlParameter("@Contra", _Contrasena))
        cmd.Parameters.Add(New SqlParameter("@Tipo", SqlDbType.Int))
        cmd.Parameters.Add(New SqlParameter("@Existe", SqlDbType.Int))
        cmd.Parameters("@Existe").Direction = ParameterDirection.Output
        cmd.Parameters("@Tipo").Direction = ParameterDirection.Output
        cnx.Open()
        cmd.ExecuteScalar()
        cnx.Close()
        existe = cmd.Parameters("@Existe").Value
        _IsAdmin = cmd.Parameters("@Tipo").Value
        Return existe
    End Function


End Class
