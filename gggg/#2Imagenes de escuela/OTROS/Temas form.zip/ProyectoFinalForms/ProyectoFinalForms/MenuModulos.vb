﻿Public Class MenuModulos
    Private Sub MenuModulos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If variablesGlobales.Tipo = 0 Then
            ButtonAltaApren.Visible = False
            ButtonAltaUsu.Visible = False
            ButtonReportes.Visible = False

        End If
        Tema = ComboBox1.Text
    End Sub

    Private Sub Salir_Click(sender As Object, e As EventArgs) Handles Salir.Click
        Form1.Close()
    End Sub

    Private Sub ButtonAprendizaje_Click(sender As Object, e As EventArgs) Handles ButtonAprendizaje.Click
        FrmAprendizaje.Show()
        Me.Hide()

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
End Class