﻿Imports System.Data.SqlClient
Public Class FrmAprendizaje
    Private Sub FrmAprendizaje_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If MenuModulos.ComboBox1.SelectedIndex = 0 Then
            PictureBox1.Image = My.Resources.antivirus
        End If
        If MenuModulos.ComboBox1.SelectedIndex = 1 Then
            PictureBox1.Image = My.Resources.malware
        End If
        If MenuModulos.ComboBox1.SelectedIndex = 2 Then
            PictureBox1.Image = My.Resources.formatear
        End If
        Dim consultar As New ClasesProyecto.Temas
        With consultar
            .Tema = MenuModulos.ComboBox1.Text
            If consultar.TemaConsulta Then
                lbltema.Text = .Tema
                TextBox1.Text = .Objetivo

            End If
        End With


    End Sub

    Private Sub lbltema_Click(sender As Object, e As EventArgs) Handles lbltema.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        MenuModulos.Show()




    End Sub
End Class