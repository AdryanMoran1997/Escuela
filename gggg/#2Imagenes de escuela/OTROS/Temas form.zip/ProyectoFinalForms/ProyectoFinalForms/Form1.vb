﻿Imports ClasesProyecto

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ButtonIniciar_Click(sender As Object, e As EventArgs) Handles ButtonIniciar.Click
        Dim iniciarSesion As New Usuario
        With iniciarSesion
            .Nombre = TextBoxUsuario.Text
            .Contrasena = TextBoxContra.Text
        End With
        If iniciarSesion.IniciarSesion > 0 Then
            variablesGlobales.Tipo = iniciarSesion.IsAdmin
            MenuModulos.Show()
            Me.Hide()
        Else
            MsgBox("Nombre o contraseña incorrecto")
        End If

    End Sub
End Class
