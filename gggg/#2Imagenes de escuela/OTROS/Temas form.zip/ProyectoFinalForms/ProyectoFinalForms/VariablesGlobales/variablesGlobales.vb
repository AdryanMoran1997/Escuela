﻿Module variablesGlobales
    Public Tipo As New Integer
    Public Tema As String


End Module
