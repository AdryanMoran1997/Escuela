﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuModulos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.ButtonAprendizaje = New System.Windows.Forms.Button()
        Me.ButtonPracticas = New System.Windows.Forms.Button()
        Me.ButtonVideos = New System.Windows.Forms.Button()
        Me.ButtonTest = New System.Windows.Forms.Button()
        Me.ButtonAltaApren = New System.Windows.Forms.Button()
        Me.ButtonAltaUsu = New System.Windows.Forms.Button()
        Me.ButtonReportes = New System.Windows.Forms.Button()
        Me.Salir = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.74468!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.25532!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 207.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 207.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonAprendizaje, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonPracticas, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonVideos, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonTest, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonAltaApren, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonAltaUsu, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.ButtonReportes, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Salir, 3, 2)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(12, 122)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.26866!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.73134!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 126.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(798, 362)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'ButtonAprendizaje
        '
        Me.ButtonAprendizaje.BackColor = System.Drawing.Color.LightCoral
        Me.ButtonAprendizaje.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAprendizaje.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonAprendizaje.Location = New System.Drawing.Point(3, 3)
        Me.ButtonAprendizaje.Name = "ButtonAprendizaje"
        Me.ButtonAprendizaje.Size = New System.Drawing.Size(169, 103)
        Me.ButtonAprendizaje.TabIndex = 0
        Me.ButtonAprendizaje.Text = "Aprendizaje"
        Me.ButtonAprendizaje.UseVisualStyleBackColor = False
        '
        'ButtonPracticas
        '
        Me.ButtonPracticas.BackColor = System.Drawing.Color.YellowGreen
        Me.ButtonPracticas.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonPracticas.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonPracticas.Location = New System.Drawing.Point(178, 3)
        Me.ButtonPracticas.Name = "ButtonPracticas"
        Me.ButtonPracticas.Size = New System.Drawing.Size(202, 103)
        Me.ButtonPracticas.TabIndex = 1
        Me.ButtonPracticas.Text = "Practicas"
        Me.ButtonPracticas.UseVisualStyleBackColor = False
        '
        'ButtonVideos
        '
        Me.ButtonVideos.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ButtonVideos.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonVideos.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonVideos.Location = New System.Drawing.Point(386, 3)
        Me.ButtonVideos.Name = "ButtonVideos"
        Me.ButtonVideos.Size = New System.Drawing.Size(201, 103)
        Me.ButtonVideos.TabIndex = 2
        Me.ButtonVideos.Text = "Videos"
        Me.ButtonVideos.UseVisualStyleBackColor = False
        '
        'ButtonTest
        '
        Me.ButtonTest.BackColor = System.Drawing.Color.SkyBlue
        Me.ButtonTest.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonTest.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonTest.Location = New System.Drawing.Point(593, 3)
        Me.ButtonTest.Name = "ButtonTest"
        Me.ButtonTest.Size = New System.Drawing.Size(199, 103)
        Me.ButtonTest.TabIndex = 3
        Me.ButtonTest.Text = "Test"
        Me.ButtonTest.UseVisualStyleBackColor = False
        '
        'ButtonAltaApren
        '
        Me.ButtonAltaApren.BackColor = System.Drawing.Color.SlateBlue
        Me.ButtonAltaApren.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAltaApren.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonAltaApren.Location = New System.Drawing.Point(3, 112)
        Me.ButtonAltaApren.Name = "ButtonAltaApren"
        Me.ButtonAltaApren.Size = New System.Drawing.Size(169, 120)
        Me.ButtonAltaApren.TabIndex = 4
        Me.ButtonAltaApren.Text = "Alta Aprendizaje"
        Me.ButtonAltaApren.UseVisualStyleBackColor = False
        '
        'ButtonAltaUsu
        '
        Me.ButtonAltaUsu.BackColor = System.Drawing.Color.PaleVioletRed
        Me.ButtonAltaUsu.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAltaUsu.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonAltaUsu.Location = New System.Drawing.Point(178, 112)
        Me.ButtonAltaUsu.Name = "ButtonAltaUsu"
        Me.ButtonAltaUsu.Size = New System.Drawing.Size(202, 120)
        Me.ButtonAltaUsu.TabIndex = 5
        Me.ButtonAltaUsu.Text = "Alta Usuario"
        Me.ButtonAltaUsu.UseVisualStyleBackColor = False
        '
        'ButtonReportes
        '
        Me.ButtonReportes.BackColor = System.Drawing.Color.Orange
        Me.ButtonReportes.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonReportes.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ButtonReportes.Location = New System.Drawing.Point(386, 112)
        Me.ButtonReportes.Name = "ButtonReportes"
        Me.ButtonReportes.Size = New System.Drawing.Size(201, 120)
        Me.ButtonReportes.TabIndex = 6
        Me.ButtonReportes.Text = "Reportes Resultados"
        Me.ButtonReportes.UseVisualStyleBackColor = False
        '
        'Salir
        '
        Me.Salir.BackColor = System.Drawing.Color.Brown
        Me.Salir.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Salir.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Salir.Location = New System.Drawing.Point(593, 238)
        Me.Salir.Name = "Salir"
        Me.Salir.Size = New System.Drawing.Size(200, 121)
        Me.Salir.TabIndex = 7
        Me.Salir.Text = "Salir"
        Me.Salir.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Seleccione el tema:"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Uso de Antivirus", "Uso de Anti-Malware", "Formateo de PC"})
        Me.ComboBox1.Location = New System.Drawing.Point(180, 55)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(154, 21)
        Me.ComboBox1.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(303, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(206, 24)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Sistema de aprendizaje"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(665, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(145, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "aqui va el nombre del usuario"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(668, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "aqui va la fecha"
        '
        'MenuModulos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(822, 496)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "MenuModulos"
        Me.Text = "MenuModulos"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents ButtonAprendizaje As Button
    Friend WithEvents ButtonPracticas As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ButtonVideos As Button
    Friend WithEvents ButtonTest As Button
    Friend WithEvents ButtonAltaApren As Button
    Friend WithEvents ButtonAltaUsu As Button
    Friend WithEvents ButtonReportes As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Salir As Button
End Class
